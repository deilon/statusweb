<?php

require_once 'includes/init.php';
$session->logout();
redirect_to("index.php");

?>
