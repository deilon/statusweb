<?php

class UserIdentity extends User {

  protected function init_name() {

  }

}

?>
